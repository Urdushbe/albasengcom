from django.contrib import admin
from .models import Job, Region, City

admin.site.register(Job)
admin.site.register(Region)
admin.site.register(City)
